# Ambiance originale — Budget Clair, Les chemins

Cette petite composition instrumentale et les bruitages ont été créés spécialement pour la publicité. Ils sont synthétisés localement par `scripts/make-ambience.py` avec NumPy et SciPy : aucun enregistrement, sample de banque sonore, boucle, chant ou voix tiers n’a été utilisé. Aucun service payant, compte externe ou achat n’a été nécessaire.

Le registre est volontairement doux : quelques notes de clavier feutré/pincé, de petits accords consonants en ré majeur et des contacts d’argile discrets. Le clavier est une synthèse harmonique, pas un enregistrement de piano acoustique. Les plops, tracés et étirements sont des oscillateurs graves et du bruit filtré, avec attaques et fins adoucies.

La création est livrée pour être utilisée et modifiée dans cette publicité Budget Clair, y compris pour sa diffusion commerciale. Il n’y a pas de piste de stock ni de licence musicale tierce à acquitter. Les dépendances techniques ne fournissent aucun contenu sonore.

## Fichiers

- `ambiance-les-chemins.wav` : musique et bruitages combinés, à placer sous la voix off.
- `musique-seule.wav` : stem musical séparé.
- `bruitages-seuls.wav` : stem des contacts et transitions.
- `controle-ambiance.json` : durée, nombre d’échantillons, niveaux et horaires précis.

Les trois WAV sont en PCM 24 bits, stéréo, 48 kHz, **35 secondes exactes**. Les deux stems sont livrés déjà équilibrés : leur addition reproduit l’ambiance à l’arrondi PCM près. La crête du mix d’ambiance est limitée à −22,4 dBFS, pour rester nettement sous la narration. Le mixage final peut l’abaisser encore pendant la parole.

Les bruitages cessent à 29 secondes. La résolution musicale commence à 32,4 secondes et ne comporte plus d’accent marqué ; la résonance se relâche progressivement, avec les 70 dernières millisecondes au silence numérique. Il n’y a aucune coupure franche de musique en fin de film.

## Reproduire

Python 3, NumPy et SciPy, depuis la racine du projet :

```sh
python3 scripts/make-ambience.py
```

La graine fixe `3519` rend les variations déterministes avec les mêmes versions de ces bibliothèques. Les notes, les niveaux et tous les minutages restent modifiables dans le script.
