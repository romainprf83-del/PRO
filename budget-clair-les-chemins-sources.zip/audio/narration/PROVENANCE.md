# Narration française — Budget Clair, Les chemins

Cette narration est une synthèse vocale locale créée pour la publicité avec Kokoro-82M v1.0, voix française `ff_siwis`, moteur `kokoro-onnx`. Aucun service payant, compte externe, abonnement ni clonage de voix n’a été utilisé. Le modèle est sous Apache 2.0 et le moteur sous MIT ; leurs licences sont incluses dans ce dossier.

Le texte est celui du brief utilisateur, intégralement conservé. La phrase « Moi, c’est Romain » appartient à ce texte de présentation : la piste est une voix synthétique, pas la voix réelle de Romain et pas un témoignage client.

La vitesse de synthèse est normale (1,0). Aucun étirement ou changement de vitesse après synthèse. Les phrases complètes sont placées avec des pauses ; seuls les blancs externes des prises ont été raccourcis, avec une marge préservée autour de la parole. La parole cumulée dure 25,341 secondes sur une piste de 35,000 secondes. La dernière phrase complète finit à 33,237 secondes.

`voix-off.wav` : PCM 24 bits, stéréo 48 kHz, 35 secondes exactes. Niveau intégré mesuré : −16,11 LUFS ; crête vraie : −5,51 dBTP ; aucun écrêtage. `voix-off.mp3` est une copie d’écoute. Les quinze segments source restent à 24 kHz.

`synchronisation.json` contient les quinze repères audio réels. `captions.json` contient treize groupes d’affichage : la question « Mais est-ce qu’il reste une place pour ce qui compte pour toi ? » et la phrase « Puis, on fait un point pour ajuster ce qui en a besoin. » réunissent chacune deux segments audio sur deux lignes. Chaque groupe conserve `start` et `end` comme bornes réelles de parole ; `display_end` prolonge éventuellement la lecture dans la pause suivante, sans empiéter sur le groupe suivant. Le SRT utilise ces maintiens lisibles. À 44 px, Manrope 600, les lignes mesurent au plus 702,66 px pour 760 px disponibles ; voir `controle-sous-titres.json`.

Sources :

- https://huggingface.co/hexgrad/Kokoro-82M
- https://github.com/thewh1teagle/kokoro-onnx
- https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.0

Pour reproduire : Python 3, NumPy, `onnxruntime`, `kokoro-onnx`, `soundfile`, eSpeak NG et FFmpeg. Définir `KOKORO_MODEL_DIR` vers le dossier contenant `kokoro-v1.0.onnx` et `voices-v1.0.bin`, puis exécuter `scripts/voice-generate.py` et `scripts/voice-assemble.py` depuis la racine du projet. Aucune clé API. Les WAV fournis suffisent au montage sans régénérer le modèle.
