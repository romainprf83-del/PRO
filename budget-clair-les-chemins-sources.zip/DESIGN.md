# Budget Clair — Les chemins

## Style Prompt
Miniatures tactiles et pâte à modeler, accueillantes et adultes. Les trois illustrations originales restent aplaties, dans leurs proportions. Autour, des pastilles épaisses, des rubans souples et des cadres arrondis se construisent avec de petits rebonds. L’orange relie les dépenses aux projets, puis au budget accompagné. Une seule famille typographique nette évite de rendre le sujet infantile.

## Colors
- Ivoire #FAEBDD : espace et respiration.
- Bleu cobalt #2848A8 : titres, structure et signature.
- Orange abricot #ED9D65 : chemin, accents et mot BUDGET.
- Lavande #A88AC6 : catégories et seconde transition.
- Encre #28314C : texte secondaire et sous-titres.

## Typography
Manrope variable, embarquée localement : 800 pour les titres, 600 pour les sous-titres et légendes. Titres 64–112 px, cartes 38–44 px, sous-titres 44 px. Lettres serrées et lignes délibérément composées dans le SVG.

## Motion
Caméra lente et uniforme sur les décors ; formes graphiques seules étirées. Rebonds courts back.out, lignes power2.inOut, cadrages sine.inOut. Transitions couvrantes de pâte orange/lavande. Message final entièrement stable de 29 à 35 s. Sous-titres indépendants en bas, au-dessus des 300 px réservés à l’interface.

## What NOT to Do
- Ne pas étirer, articuler ou isoler artificiellement les personnages.
- Ne pas annoncer de résultat financier garanti, de cadeau ou de témoignage.
- Ne pas appeler à envoyer un message privé.
- Ne pas masquer les visages avec les cartes.
- Ne pas animer le CTA pendant les six dernières secondes.
