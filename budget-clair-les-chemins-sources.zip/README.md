# Budget Clair — Les chemins

Publicité verticale de 35 secondes pour présenter l’accompagnement Budget Clair. Les trois illustrations en pâte à modeler fournies par l’utilisateur sont intégrées dans leurs proportions d’origine. Les mouvements de caméra, les rubans, les pastilles et les cartes sont créés séparément ; les personnages des illustrations restent aplatis.

<!-- DELIVERY-STATUS:START -->
**Statut : MP4 exporté et contrôlé.** Les 25 contrôles techniques ont réussi sur le fichier `budget-clair-les-chemins.mp4` (SHA256 `a6ac5133d20f2f15791c4bb77c18f4c4dc7ef4704aae537c73b3effce46c58bd`). La revue des captures réelles a été confirmée par l’opérateur au conditionnement. La piste AAC, ses niveaux et la conservation de la dernière phrase sont contrôlés par décodage et comparaison au mixage source. Les archives sont produites avec leurs empreintes.
<!-- DELIVERY-STATUS:END -->

## Fichiers de livraison

| Fichier dans `output/` | Contenu |
| --- | --- |
| `budget-clair-les-chemins.mp4` | Film final, 1080 × 1920, 30 i/s, 35 s, H.264, yuv420p, audio AAC, faststart |
| `budget-clair-les-chemins-mobile.mp4` | Copie plus légère, 720 × 1280, H.264 Baseline niveau 3.1, yuv420p, AAC, faststart |
| `budget-clair-les-chemins-mobile.mp4` | Copie légère, 720 × 1280, H.264 Baseline/AAC, faststart |
| `budget-clair-les-chemins-couverture.png` | Couverture verticale 1080 × 1920 |
| `budget-clair-les-chemins-livraison.zip` | MP4 HD et léger, couverture, voix séparée WAV/MP3, texte exact, SRT et rapport technique |
| `budget-clair-les-chemins-sources.zip` | Composition, médias, audio, scripts, documentation et manifestes ; sans dépendances installées ni rendus |
| `SHA256SUMS.txt` | Empreintes des deux ZIP, du MP4 et de la couverture |

Le MP4 et la couverture existent ; les archives sont créées après les contrôles et la revue des captures. Le résultat de `output/qa/qa-final.json` identifie le fichier vidéo contrôlé. `scripts/package-delivery.py` refuse de créer les ZIP tant que le MP4 réel, la couverture et un contrôle technique réussi correspondant au SHA256 du MP4 ne sont pas disponibles. Les captures extraites doivent également avoir été revues avant son exécution finale.

## Contenu du film

| Temps | Séquence |
| --- | --- |
| 0–9 s | Les dépenses dans la ville, puis la question des projets |
| 9–15 s | Le voyage, le premier appartement et la réserve pour les imprévus |
| 15–23 s | Présentation de Romain, échange sur la situation et tableau simple |
| 23–29 s | Le point de suivi pour ajuster |
| 29–35 s | « ÉCRIS BUDGET EN COMMENTAIRE », message principal fixe |

La narration conserve le texte exact du brief dans `texte-voix-off.txt` et `audio/narration/texte-exact.txt`. Elle finit à 33,237 s et dispose d’une fin complète avant la résolution musicale. Les sous-titres reproduisent toute la narration ; ils restent dans une zone distincte du message final. Le découpage courant comporte treize groupes, sur deux lignes maximum, en Manrope 44 px. La composition peut ainsi être comprise sans son.

Les personnages sont des illustrations fictives. Ils ne représentent ni Romain ni des clients réels. La phrase « Moi, c’est Romain » est prononcée par une **voix de synthèse locale**, Kokoro `ff_siwis` ; il ne s’agit pas de la voix réelle de Romain. Le débit de synthèse est 1,0 et aucun étirement temporel n’a été appliqué après génération.

La musique et les bruitages sont une création originale synthétisée localement avec NumPy et SciPy. Ils sont équilibrés sous la narration, avec une atténuation supplémentaire pendant la parole. Aucun service payant, achat, boucle de banque sonore ou clonage de voix n’a été utilisé. Le CTA demande un commentaire « BUDGET ».

## Sources et reproduction

`index.html`, `composition.js` et `captions-data.js` forment la composition HyperFrames/GSAP. Les trois PNG originaux, la police Manrope et GSAP sont embarqués dans `assets/`. `scene-plan.json`, `DESIGN.md` et `assets-manifest.json` décrivent le montage et les médias. Les fichiers de narration et d’ambiance sont livrés dans `audio/`, avec les scripts de génération dans `scripts/`.

Voir `Refaire-le-rendu.txt` pour l’installation, le rendu, la couverture, la conversion compatible et les vérifications. Les WAV prêts à l’emploi suffisent pour refaire le film ; le modèle vocal lourd n’est pas inclus dans le ZIP. Sa régénération est facultative et documentée séparément.

La version du projet utilise Node.js 22 ou supérieur, HyperFrames 0.8.209, GSAP 3.14.2 et puppeteer-core 25.16.0. Les dépendances déclarées dans `package.json` doivent être installées sur la machine de rendu. Les dossiers `node_modules`, `.git`, `output`, les caches et les fichiers temporaires sont exclus de l’archive des sources.

Après le rendu HyperFrames, `npm run export` exécute `scripts/export-compatible.py`. Il ajoute faststart au MP4 HD par remuxage sans perte lorsque ses pistes sont déjà H.264/yuv420p et AAC stéréo 48 kHz ; il les convertit si nécessaire. Il crée aussi la copie mobile 720 × 1280 en H.264 Baseline 3.1. La narration conserve sa vitesse.

## Contrôles du fichier réellement exporté

Le script `scripts/qa-final.py` décode le MP4 final et vérifie sa durée, ses 1 050 images, les codecs H.264/AAC, le format yuv420p, le faststart, la présence d’une piste audio et le signal de la dernière phrase. Il compare également cette fin au mixage source. Il extrait des images de chaque séquence, des transitions, des sous-titres et des six dernières secondes afin de contrôler les cadrages et la stabilité du CTA. Les résultats numériques sont dans `output/qa/qa-final.json` ; les planches doivent être examinées avant livraison.

Le contrôle audio repose sur le décodage, les niveaux et la corrélation avec le mixage. La revue des captures et ces mesures sont rapportées séparément ; elles ne constituent pas une attestation d’écoute humaine. Une écoute du MP4 complet est conseillée sur la machine de lecture.

Les mesures ne garantissent pas la lecture dans l’aperçu d’une application donnée. Le MP4 reste le fichier vidéo ; le ZIP permet de le télécharger sans ouvrir cet aperçu. Après extraction du ZIP, ouvrir le MP4 dans un lecteur vidéo ou un navigateur compatible H.264/AAC.

## Provenance et licences

Les images sont les originaux fournis par l’utilisateur pour cette publicité, sans revendication de création par ce projet. Manrope est accompagnée de sa licence OFL dans `assets/fonts/`. Les licences du modèle Kokoro et du moteur local sont incluses dans `audio/narration/`, ainsi que `PROVENANCE.md`. La provenance de la création musicale est décrite dans `audio/ambiance/PROVENANCE.md`. Les dépendances logicielles conservent leurs licences respectives.
