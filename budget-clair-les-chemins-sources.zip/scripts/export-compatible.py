#!/usr/bin/env python3
"""Créer les MP4 de livraison à partir du rendu HyperFrames fermé et terminé."""
from pathlib import Path
import json
import subprocess

root=Path(__file__).resolve().parents[1]
source=root/'output/budget-clair-les-chemins-rendu.mp4'
final=root/'output/budget-clair-les-chemins.mp4'
mobile=root/'output/budget-clair-les-chemins-mobile.mp4'
if not source.is_file():
    raise SystemExit('Rendu source absent : terminer HyperFrames avant cet export.')
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(source)]))
video=next(s for s in probe['streams'] if s['codec_type']=='video')
audio=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert (video['width'],video['height'])==(1080,1920)
assert abs(float(video['duration'])-35)<.04
vflags=['-c:v','copy'] if video['codec_name']=='h264' and video['pix_fmt']=='yuv420p' else ['-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p']
aflags=['-c:a','copy'] if audio['codec_name']=='aac' and audio['sample_rate']=='48000' and audio['channels']==2 else ['-c:a','aac','-b:a','192k','-ar','48000','-ac','2']
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(source),'-map','0:v:0','-map','0:a:0',*vflags,*aflags,'-movflags','+faststart','-metadata','title=Budget Clair — Les chemins',str(final)],check=True)
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(final),'-map','0:v:0','-map','0:a:0','-vf','scale=720:1280:flags=lanczos,setsar=1','-c:v','libx264','-preset','medium','-crf','25','-profile:v','baseline','-level:v','3.1','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-ar','48000','-ac','2','-movflags','+faststart',str(mobile)],check=True)
print(json.dumps({'final':str(final),'bytes':final.stat().st_size,'mobile':str(mobile),'mobile_bytes':mobile.stat().st_size},ensure_ascii=False,indent=2))
