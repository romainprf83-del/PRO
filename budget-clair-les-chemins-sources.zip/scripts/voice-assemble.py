"""Place complete French utterances on 35 s; normalize level, never alter speed."""
from pathlib import Path
import json,re,subprocess,shutil
import numpy as np
import soundfile as sf

ROOT=Path(__file__).resolve().parents[1];DEST=ROOT/'audio/narration'
RATE=24000;DURATION=35
STARTS=[.15,2.12,4.5,6.4,9.2,11.7,15.1,16.45,18.86,20.95,23.15,24.95,26.85,29.6,31.65]
LINES=[
 ['Ton argent prend','plusieurs chemins :'],
 ['le logement, les courses,','les sorties…'],
 ['Mais est-ce qu’il reste','une place'],
 ['pour ce qui compte pour toi ?'],
 ['Un voyage,','ton premier appartement,'],
 ['ou une réserve pour les imprévus.'],
 ['Moi, c’est Romain.'],
 ['Avec Budget Clair,','on regarde ensemble'],
 ['ta situation et tes priorités.'],
 ['Je te prépare un tableau simple,'],
 ['adapté à ton quotidien.'],
 ['Puis, on fait un point','pour ajuster'],
 ['ce qui en a besoin.'],
 ['Pour découvrir','l’accompagnement,'],
 ['écris BUDGET en commentaire.'],
]
segments=json.loads((DEST/'segments.json').read_text())
track=np.zeros(RATE*DURATION,dtype=np.float64);cues=[]
for seg,start,lines in zip(segments,STARTS,LINES,strict=True):
 data,sr=sf.read(DEST/seg['file']);assert sr==RATE
 a=round(start*RATE);b=a+len(data)
 assert b<=len(track) and not track[a:b].any()
 assert ' '.join(lines)==seg['text']
 track[a:b]=data
 cues.append({'id':seg['id'],'start':start,'end':b/RATE,'text':seg['text'],'lines':lines,'file':seg['file']})
sf.write(DEST/'assemblage-brut.wav',track,RATE,subtype='PCM_24')
def ffmpeg(*args):
 return subprocess.run(['ffmpeg','-hide_banner',*args],capture_output=True,text=True,check=True)
raw=ffmpeg('-i',str(DEST/'assemblage-brut.wav'),'-af','loudnorm=I=-16:TP=-2.5:LRA=7:print_format=json','-f','null','-')
levels=json.JSONDecoder().raw_decode(raw.stderr[raw.stderr.rfind('{'):])[0]
af='loudnorm=I=-16:TP=-2.5:LRA=7:linear=true:'+':'.join(f'{k}={levels[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])
ffmpeg('-y','-i',str(DEST/'assemblage-brut.wav'),'-af',af,'-ar','48000','-ac','2','-c:a','pcm_s24le',str(DEST/'voix-off.wav'))
ffmpeg('-y','-i',str(DEST/'voix-off.wav'),'-c:a','libmp3lame','-b:a','192k',str(DEST/'voix-off.mp3'))
final=ffmpeg('-i',str(DEST/'voix-off.wav'),'-af','loudnorm=I=-16:TP=-2.5:LRA=7:print_format=json','-f','null','-')
final_levels=json.JSONDecoder().raw_decode(final.stderr[final.stderr.rfind('{'):])[0]
data,sr=sf.read(DEST/'voix-off.wav')
assert sr==48000 and data.shape==(1680000,2) and np.max(np.abs(data))<1
assert cues[-1]['end']<34.8
# Complete questions/sentences stay together, with their actual audio span.
captions=[dict(c) for c in cues[:2]]
captions.append({'id':3,'start':cues[2]['start'],'end':cues[3]['end'],
 'text':cues[2]['text']+' '+cues[3]['text'],
 'lines':['Mais est-ce qu’il reste une place','pour ce qui compte pour toi ?'],
 'source_ids':[3,4]})
captions += [dict(c) for c in cues[4:11]]
captions.append({'id':12,'start':cues[11]['start'],'end':cues[12]['end'],
 'text':cues[11]['text']+' '+cues[12]['text'],
 'lines':['Puis, on fait un point','pour ajuster ce qui en a besoin.'],
 'source_ids':[12,13]})
captions += [dict(c) for c in cues[13:]]
for i,c in enumerate(captions):
 assert ' '.join(c['lines'])==c['text']
 words=len(c['text'].split())
 next_start=captions[i+1]['start'] if i+1<len(captions) else 35
 c['display_end']=min(next_start-.08,max(c['end'],c['start']+.55+.27*words))
 if c['id']==3:
  c['display_end']=8.84
report={'duration':DURATION,'sample_rate':sr,'channels':2,'voice':'ff_siwis','language':'fr-fr','synthesis_speed':1.0,'time_stretched':False,
 'speech_duration':sum(s['duration'] for s in segments),'last_phrase_end':cues[-1]['end'],
 'peak_dbfs':float(20*np.log10(np.max(np.abs(data)))),'levels':final_levels,'cues':cues,'captions':captions}
(DEST/'synchronisation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(DEST/'captions.json').write_text(json.dumps(captions,ensure_ascii=False,indent=2)+'\n')
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d},{ms%1000:03d}'
srt='\n\n'.join(f"{i}\n{stamp(c['start'])} --> {stamp(c['display_end'])}\n"+'\n'.join(c['lines']) for i,c in enumerate(captions,1))+'\n'
(DEST/'sous-titres.srt').write_text(srt)
paragraphs=[cues[:4],cues[4:6],cues[6:9],cues[9:13],cues[13:]]
text='\n\n'.join(' '.join(c['text'] for c in group) for group in paragraphs)+'\n'
(DEST/'texte-exact.txt').write_text(text)
# The brief may be absent on another machine; its comparison is a creation-time check.
brief=Path('/workspace/attachments/729f784b-4b45-4ea2-8763-d4c40c0dafb3/Texte collé.txt')
if brief.is_file():
 expected=re.search(r'VOIX OFF.*?«\s*(.*?)\s*»',brief.read_text(),re.S).group(1)
 assert ' '.join(expected.split())==' '.join(text.split()),'Narration must match the exact brief'
for name in ['LICENCE-modele-Kokoro.txt','LICENCE-moteur-Kokoro.txt']:
 source=Path('/workspace/budget-clair-carnet/audio/narration')/name
 if source.is_file():shutil.copy2(source,DEST/name)
print(json.dumps({k:v for k,v in report.items() if k not in ['cues','captions']},ensure_ascii=False,indent=2))
for c in captions:print(f"{c['start']:.2f}–{c['end']:.3f} (lecture jusqu’à {c['display_end']:.3f}) {c['text']}")
