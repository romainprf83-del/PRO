import fs from 'node:fs';import http from 'node:http';import path from 'node:path';import puppeteer from 'puppeteer-core';
const root=process.cwd();
const html=fs.readFileSync('index.html','utf8').replace('data-composition-id="chemins"','data-cover="true"').replace(/<audio[^>]*><\/audio>/,'').replace("window.__timelines=window.__timelines||{};window.__timelines['chemins']=buildChemins();","buildCheminsCover();");
fs.writeFileSync('cover.html',html);
const server=http.createServer((req,res)=>{const url=decodeURIComponent((req.url||'/').split('?')[0]);const file=path.join(root,url==='/'?'cover.html':url);try{res.setHeader('Content-Type',({'.html':'text/html','.js':'application/javascript','.ttf':'font/ttf','.png':'image/png'})[path.extname(file)]||'application/octet-stream');res.end(fs.readFileSync(file));}catch{res.statusCode=404;res.end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await puppeteer.launch({executablePath:process.env.HYPERFRAMES_BROWSER_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
try{const page=await browser.newPage();await page.setViewport({width:1080,height:1920,deviceScaleFactor:1});await page.goto('http://127.0.0.1:'+server.address().port+'/',{waitUntil:'networkidle0'});await page.evaluate(async()=>{await document.fonts.load('800 75px Manrope');return true;});await page.screenshot({path:'output/budget-clair-les-chemins-couverture.png'});console.log('Couverture PNG exportée 1080 × 1920.');}finally{await browser.close();server.closeAllConnections();server.close();}
