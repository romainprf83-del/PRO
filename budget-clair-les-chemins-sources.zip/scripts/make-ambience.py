#!/usr/bin/env python3
"""Original, quiet 35 s score and clay SFX. No recordings or external samples.

Python 3 + NumPy + SciPy. Reproduce from the project root with:
    python3 scripts/make-ambience.py
"""
from pathlib import Path
import json
import wave
import numpy as np
from scipy import signal

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'audio' / 'ambiance'
OUT.mkdir(parents=True, exist_ok=True)
SR = 48000
DURATION = 35
N = SR * DURATION
rng = np.random.default_rng(3519)
music = np.zeros((N, 2), dtype=np.float64)
sfx = np.zeros_like(music)
events = []


def frequency(midi):
    return 440 * 2 ** ((midi - 69) / 12)


def taper(values, attack=.008, release=.05):
    values = np.array(values, copy=True)
    a = min(round(attack * SR), len(values))
    b = min(round(release * SR), len(values))
    values[:a] *= np.sin(np.linspace(0, np.pi / 2, a)) ** 2
    values[-b:] *= np.sin(np.linspace(np.pi / 2, 0, b)) ** 2
    return values


def put(track, values, when, gain=1, pan=0):
    start = round(when * SR)
    count = min(len(values), N - start)
    if count <= 0:
        return
    if values.ndim == 1:
        theta = (np.clip(pan, -1, 1) + 1) * np.pi / 4
        track[start:start + count] += gain * values[:count, None] * np.array([np.cos(theta), np.sin(theta)])
    else:
        track[start:start + count] += gain * values[:count]


def felt_note(midi, duration=3.5, velocity=.5):
    """A damped plucked/felt-key sound, deliberately warm rather than a bright bell."""
    t = np.arange(round(duration * SR)) / SR
    f = frequency(midi)
    values = np.zeros_like(t)
    # Light independent beating gives a warm body without a sustained synth pad.
    for harmonic in range(1, 10):
        stiffness = .00010 * harmonic * harmonic
        f_h = f * harmonic * np.sqrt(1 + stiffness)
        if f_h > 13000:
            break
        decay = np.exp(-t * (.9 + .4 * harmonic))
        level = np.exp(-.28 * harmonic) / harmonic ** 1.1
        phase = harmonic * .07
        values += level * decay * (
            .8 * np.sin(2 * np.pi * f_h * t + phase)
            + .2 * np.sin(2 * np.pi * f_h * 1.0009 * t + phase)
        )
    hammer = rng.standard_normal(len(t))
    hammer = signal.sosfilt(signal.butter(2, [300, 2600], btype='bandpass', fs=SR, output='sos'), hammer)
    values += hammer * np.exp(-t * 95) * .018
    return taper(values * velocity * .20, .012, .13)


def clay_pop(duration=.16, pitch=260, strength=.45):
    t = np.arange(round(duration * SR)) / SR
    # Rounded falling pitch and a filtered low contact, with no sharp crack.
    f = pitch * (.60 + .40 * np.exp(-t * 28))
    phase = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(phase) + .12 * np.sin(2 * phase)
    envelope = np.exp(-t * 24) * np.sin(np.pi * np.clip(t / duration, 0, 1)) ** .35
    noise = signal.sosfilt(signal.butter(2, 1100, fs=SR, output='sos'), rng.standard_normal(len(t)))
    return taper((body * envelope + noise * np.exp(-t * 40) * .14) * strength * .15, .008, .035)


def stretch(duration, strength=.3):
    t = np.arange(round(duration * SR)) / SR
    u = t / duration
    bend = 155 + 65 * np.sin(np.pi * u) - 18 * u
    phase = 2 * np.pi * np.cumsum(bend) / SR
    noise = signal.sosfilt(signal.butter(2, [160, 2200], btype='bandpass', fs=SR, output='sos'), rng.standard_normal(len(t)))
    envelope = np.sin(np.pi * u) ** 1.7
    sound = .23 * np.sin(phase) + noise * .21
    return taper(sound * envelope * strength * .14, .025, .06)


def draw_line(duration=1.2):
    t = np.arange(round(duration * SR)) / SR
    noise = signal.sosfilt(signal.butter(2, [350, 2200], btype='bandpass', fs=SR, output='sos'), rng.standard_normal(len(t)))
    envelope = np.sin(np.pi * t / duration) ** 1.5
    strokes = .45 + .55 * (.5 + .5 * np.sin(2 * np.pi * 5.1 * t + .3))
    return taper(noise * envelope * strokes * .026, .035, .07)


# Five consonant areas follow the visual sections: D, G6, Dadd9, Aadd9, D.
# These voicings and the short melody below were composed for this advertisement.
harmony = [
    (.22, [50, 57, 62, 66], .37), (3.7, [50, 57, 64, 66], .31),
    (7.0, [50, 57, 62, 69], .28), (9.2, [43, 55, 59, 64], .34),
    (12.2, [43, 55, 62, 64], .28), (15.2, [50, 57, 62, 66], .33),
    (18.8, [50, 57, 64, 66], .29), (22.0, [50, 57, 62, 69], .27),
    (23.4, [45, 57, 61, 64], .30), (26.5, [45, 57, 64, 71], .28),
    (29.2, [50, 57, 62, 66], .31), (32.4, [50, 57, 62, 66], .35),
]
for start, notes, level in harmony:
    for i, note in enumerate(notes):
        put(music, felt_note(note, 3.1, level), start + i * .075,
            pan=float(np.linspace(-.45, .45, len(notes))[i]))

melody = [
    (.75, 66, .48), (2.75, 64, .40), (5.3, 69, .40), (7.55, 66, .36),
    (10.3, 67, .42), (12.5, 71, .36), (14.0, 69, .34),
    (16.8, 66, .40), (19.5, 64, .36), (21.7, 62, .34),
    (24.8, 64, .35), (27.1, 73, .31), (29.8, 74, .36),
    (31.45, 69, .31), (32.7, 66, .34), (32.85, 62, .27),
]
for i, (when, midi, velocity) in enumerate(melody):
    put(music, felt_note(midi, 2.7, velocity), when, pan=(-.18 if i % 2 else .18))

# Short, low reflections: space rather than an obvious delay.
dry = music.copy()
for seconds, level, reverse in [(.047, .09, True), (.093, .065, False),
                                (.163, .045, True), (.251, .025, False),
                                (.371, .016, True)]:
    shift = round(seconds * SR)
    reflected = dry[:-shift, ::-1] if reverse else dry[:-shift]
    reflected = signal.sosfilt(signal.butter(1, 3300, fs=SR, output='sos'), reflected, axis=0)
    music[shift:] += reflected * level

for i, when in enumerate([1.0, 1.7, 2.4]):
    put(sfx, clay_pop(.18, [260, 290, 240][i], .42), when, pan=[-.2, .1, .25][i])
    events.append({'time': when, 'end': when + .18, 'type': 'pastille_argile'})
put(sfx, draw_line(1.2), 4.8, pan=-.08)
events.append({'time': 4.8, 'end': 6.0, 'type': 'trace_chemin'})
for a, b in [(8.7, 9.2), (14.8, 15.2), (28.7, 29.0)]:
    put(sfx, stretch(b - a, .32), a, pan=.05)
    events.append({'time': a, 'end': b, 'type': 'etirement_argile_transition'})
for i, when in enumerate([9.8, 11.2, 12.6, 16.5, 20.1, 23.4]):
    put(sfx, clay_pop(.14, [240, 270, 300, 235, 260, 285][i], .28), when,
        pan=(-.12 if i % 2 else .12))
    events.append({'time': when, 'end': when + .14, 'type': 'petit_contact_cadre_ou_carte'})

# Musical resolution starts at 32.4 s; its tail closes gently before 35 s.
time = np.arange(N) / SR
opening = np.clip(time / .12, 0, 1)
finish = np.clip((34.93 - time) / 1.0, 0, 1) ** 1.2
music *= (opening * finish)[:, None]
music[round(34.93 * SR):] = 0
sfx[29 * SR:] = 0
combined = music + sfx
# Balance the soft keys and the short clay contacts before the shared ceiling.
# Contacts stay audible as details under speech, rather than vanishing in the mix.
music *= 10 ** (-23.4 / 20) / float(np.max(np.abs(music)))
sfx *= 10 ** (-26.5 / 20) / float(np.max(np.abs(sfx)))
combined = music + sfx
# A shared final gain keeps stems additive. The ambience remains below -22 dBFS.
shared_gain = min(1, 10 ** (-22.4 / 20) / float(np.max(np.abs(combined))))
music *= shared_gain
sfx *= shared_gain
combined = music + sfx


def write(path, values):
    packed = np.round(np.clip(values, -1, 1) * 8388607).astype('<i4').view('u1').reshape(-1, 4)[:, :3].tobytes()
    with wave.open(str(path), 'wb') as output:
        output.setnchannels(2)
        output.setsampwidth(3)
        output.setframerate(SR)
        output.writeframes(packed)


def stats(values):
    peak = float(np.max(np.abs(values)))
    rms = float(np.sqrt(np.mean(values ** 2)))
    return {'peak_dbfs': round(20 * np.log10(max(peak, 1e-12)), 4),
            'rms_dbfs': round(20 * np.log10(max(rms, 1e-12)), 4),
            'clipped_samples': int(np.count_nonzero(np.abs(values) >= 1))}


write(OUT / 'ambiance-les-chemins.wav', combined)
write(OUT / 'musique-seule.wav', music)
write(OUT / 'bruitages-seuls.wav', sfx)
report = {
    'duration': DURATION, 'sample_rate': SR, 'channels': 2, 'format': 'WAV PCM 24 bits',
    'samples_per_channel': N, 'seed': 3519,
    'combined': stats(combined), 'music': stats(music), 'sfx': stats(sfx),
    'maximum_peak_requested_dbfs': -22,
    'resolution_start': 32.4, 'tail_silent_from': 34.93,
    'last_70ms_silent': bool(np.all(combined[round(34.93 * SR):] == 0)),
    'sfx_silent_from_29s': bool(np.all(sfx[29 * SR:] == 0)),
    'source': 'Composition et synthèse originales locales ; aucun sample ou enregistrement tiers.',
    'contains_voice': False, 'paid_service_used': False, 'events': sorted(events, key=lambda e: e['time'])
}
assert combined.shape == (N, 2)
assert report['combined']['peak_dbfs'] <= -22
assert report['combined']['clipped_samples'] == 0
assert report['last_70ms_silent']
(OUT / 'controle-ambiance.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'events'}, ensure_ascii=False, indent=2))
