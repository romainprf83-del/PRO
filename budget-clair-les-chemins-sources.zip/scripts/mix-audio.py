"""Mixage original local de la narration et de l’ambiance, sans changement de vitesse."""
from pathlib import Path
import json,wave
import numpy as np
from scipy.io import wavfile
from scipy.ndimage import uniform_filter1d,maximum_filter1d
root=Path(__file__).resolve().parents[1]
def read(path):
 rate,data=wavfile.read(path);values=data.astype(np.float64)
 if np.issubdtype(data.dtype,np.integer):values/=2**(np.iinfo(data.dtype).bits-1)
 return rate,values
rate,voice=read(root/'audio/narration/voix-off.wav')
sr,ambience=read(root/'audio/ambiance/ambiance-les-chemins.wav')
assert rate==sr==48000 and voice.shape==ambience.shape==(35*48000,2)
rms=np.sqrt(uniform_filter1d(np.mean(voice**2,axis=1),size=960))
activity=uniform_filter1d(maximum_filter1d(np.clip((rms-.003)/.021,0,1),size=4801),size=2401)
mix=voice+ambience*10**(-5*activity[:,None]/20)
peak=float(np.max(np.abs(mix)));mix*=min(1,10**(-1.5/20)/peak)
packed=np.round(np.clip(mix,-1,1)*8388607).astype('<i4').view('u1').reshape(-1,4)[:,:3].tobytes()
with wave.open(str(root/'audio/budget-clair-les-chemins-mix.wav'),'wb') as out:
 out.setnchannels(2);out.setsampwidth(3);out.setframerate(sr);out.writeframes(packed)
cues=json.loads((root/'audio/narration/captions.json').read_text())
(root/'captions-data.js').write_text('window.CHEMINS_CAPTIONS = '+json.dumps(cues,ensure_ascii=False)+';\n')
report={'duration':35,'sample_rate':sr,'channels':2,'peak_dbfs':float(20*np.log10(np.max(np.abs(mix)))),'clipped_samples':int(np.count_nonzero(np.abs(mix)>=1)),'voice_end':max(c['end'] for c in cues),'post_synthesis_speed_change':False,'ambience_ducking_db':5,'final_mp4_created':False,'reason':'Trois originaux intégrés ; statut du MP4 final dans output/qa/qa-final.json après rendu et contrôle.'}
(root/'controle-mix.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
