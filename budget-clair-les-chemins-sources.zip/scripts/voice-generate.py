"""French narration generated locally at normal speed; no time stretching."""
from pathlib import Path
import os,json
import numpy as np
import onnxruntime as rt
import soundfile as sf
from kokoro_onnx import Kokoro

ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'audio/narration';DEST.mkdir(parents=True,exist_ok=True)
MODELS=Path(os.environ.get('KOKORO_MODEL_DIR','/workspace/PRO/.tts'))
TEXTS=[
 'Ton argent prend plusieurs chemins :',
 'le logement, les courses, les sorties…',
 'Mais est-ce qu’il reste une place',
 'pour ce qui compte pour toi ?',
 'Un voyage, ton premier appartement,',
 'ou une réserve pour les imprévus.',
 'Moi, c’est Romain.',
 'Avec Budget Clair, on regarde ensemble',
 'ta situation et tes priorités.',
 'Je te prépare un tableau simple,',
 'adapté à ton quotidien.',
 'Puis, on fait un point pour ajuster',
 'ce qui en a besoin.',
 'Pour découvrir l’accompagnement,',
 'écris BUDGET en commentaire.',
]
opts=rt.SessionOptions();opts.intra_op_num_threads=2;opts.inter_op_num_threads=1
session=rt.InferenceSession(str(MODELS/'kokoro-v1.0.onnx'),sess_options=opts,providers=['CPUExecutionProvider'])
model=Kokoro.from_session(session,str(MODELS/'voices-v1.0.bin'))
segments=[]
for i,text in enumerate(TEXTS,1):
 samples,rate=model.create(text,voice='ff_siwis',speed=1.0,lang='fr-fr',trim=False)
 active=np.flatnonzero(np.abs(samples)>.0025)
 assert len(active)
 a=max(0,int(active[0])-round(.05*rate));b=min(len(samples),int(active[-1])+round(.08*rate))
 samples=samples[a:b]
 ramp=min(round(.004*rate),len(samples)//2)
 samples[:ramp]*=np.linspace(0,1,ramp);samples[-ramp:]*=np.linspace(1,0,ramp)
 name=f'segment-{i:02d}.wav';sf.write(DEST/name,samples,rate,subtype='PCM_24')
 seg={'id':i,'file':name,'text':text,'duration':len(samples)/rate,'sample_rate':rate,'speed':1.0}
 segments.append(seg);print(i,round(seg['duration'],3),text,flush=True)
(DEST/'segments.json').write_text(json.dumps(segments,ensure_ascii=False,indent=2)+'\n')
print('TOTAL',sum(s['duration'] for s in segments),flush=True)
