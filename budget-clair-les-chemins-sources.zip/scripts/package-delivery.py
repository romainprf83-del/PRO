#!/usr/bin/env python3
"""Conditionne les sources et les livrables après contrôle du vrai MP4."""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import json
import re
import struct
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output'
VIDEO = OUT / 'budget-clair-les-chemins.mp4'
COVER = OUT / 'budget-clair-les-chemins-couverture.png'
VOICE = ROOT / 'audio/narration/voix-off.wav'
QA = OUT / 'qa/qa-final.json'
EXCLUDED = {'node_modules', 'output', '.git', '.venv', 'venv', '__pycache__',
            '.cache', '.pytest_cache', '.mypy_cache', '.hf', '.hyperframes',
            'renders', '.DS_Store'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def verify_png(path):
    with path.open('rb') as source:
        header = source.read(24)
    if len(header) != 24 or header[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('La couverture ne contient pas un véritable PNG.')
    if struct.unpack('>II', header[16:24]) != (1080, 1920):
        raise ValueError('La couverture doit mesurer 1080 × 1920 pixels.')


def require_ready():
    for path in [VIDEO, COVER, VOICE, QA, ROOT / 'texte-voix-off.txt',
                 ROOT / 'audio/narration/sous-titres.srt']:
        if not path.is_file() or path.stat().st_size == 0:
            raise ValueError(f'Fichier absent ou vide : {path.relative_to(ROOT)}')
    qa = json.loads(QA.read_text())
    if not qa.get('passed') or qa.get('failures'):
        raise ValueError('Le contrôle technique du MP4 ne réussit pas encore.')
    video_hash = file_digest(VIDEO)
    if qa.get('sha256') != video_hash:
        raise ValueError('Le MP4 a changé depuis la QA : relancer qa-final.py.')
    if not qa.get('faststart'):
        raise ValueError('Le rapport ne confirme pas faststart.')
    probe = json.loads(subprocess.check_output(
        ['ffprobe', '-v', 'error', '-show_streams', '-show_format',
         '-of', 'json', str(VIDEO)]))
    videos = [s for s in probe['streams'] if s['codec_type'] == 'video']
    audios = [s for s in probe['streams'] if s['codec_type'] == 'audio']
    if len(videos) != 1 or len(audios) != 1:
        raise ValueError('Une piste vidéo et une piste audio sont nécessaires.')
    v, a = videos[0], audios[0]
    if (v.get('codec_name'), v.get('pix_fmt'), v.get('width'), v.get('height'),
        a.get('codec_name')) != ('h264', 'yuv420p', 1080, 1920, 'aac'):
        raise ValueError('Format final attendu : H.264 yuv420p 1080×1920 et AAC.')
    if abs(float(probe['format']['duration']) - 35) > .08:
        raise ValueError('Le MP4 doit durer 35 secondes.')
    verify_png(COVER)
    return qa, video_hash


def source_files():
    files = []
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED or part.startswith('.hf-') for part in relative.parts):
            continue
        if path.is_symlink() or not path.is_file():
            continue
        if path.suffix.lower() in {'.pyc', '.pyo', '.tmp', '.bak'}:
            continue
        if path.name == 'cover.html':
            continue  # HTML temporaire produit par export-cover.mjs.
        files.append((relative.as_posix(), path))
    return files


def create_archive(path, files, metadata):
    """Écrit atomiquement un ZIP ; chaque membre est aussi vérifié par SHA256."""
    items = []
    for name, content in files:
        if name.startswith('/') or '..' in Path(name).parts:
            raise ValueError(f'Chemin d’archive non sûr : {name}')
        raw = content.read_bytes() if isinstance(content, Path) else content
        items.append((name, raw))
    if len({name for name, _ in items}) != len(items):
        raise ValueError('Noms de membres en double dans l’archive.')
    manifest = dict(metadata)
    manifest['files'] = [{'path': name, 'size_bytes': len(raw), 'sha256': digest(raw)}
                         for name, raw in items]
    items.append(('MANIFEST.json', json_bytes(manifest)))
    hashes = {name: digest(raw) for name, raw in items}
    checksum = ''.join(f'{value}  {name}\n' for name, value in sorted(hashes.items())).encode()
    items.append(('SHA256SUMS.txt', checksum))
    temp = path.with_suffix('.zip.tmp')
    try:
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED,
                             compresslevel=6, allowZip64=True) as archive:
            for name, raw in items:
                archive.writestr(name, raw)
        with zipfile.ZipFile(temp) as archive:
            bad = archive.testzip()
            if bad:
                raise ValueError(f'CRC incorrect pour {bad}')
            for name, expected in hashes.items():
                if digest(archive.read(name)) != expected:
                    raise ValueError(f'SHA256 incorrect dans le ZIP : {name}')
            if archive.read('SHA256SUMS.txt') != checksum:
                raise ValueError('Le fichier des empreintes est altéré.')
        temp.replace(path)
    finally:
        if temp.exists():
            temp.unlink()
    return {'name': path.name, 'size_bytes': path.stat().st_size,
            'sha256': file_digest(path), 'members': len(items)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--visual-review-confirmed', action='store_true',
                        help='Confirme la revue des captures extraites du MP4 réel.')
    args = parser.parse_args()
    if not args.visual_review_confirmed:
        parser.error('Revoir les captures avant de passer --visual-review-confirmed. '
                     'Aucun ZIP n’a été créé.')
    qa, video_hash = require_ready()
    now = datetime.now(timezone.utc).isoformat(timespec='seconds')
    status = ('**Statut : MP4 exporté et contrôlé.** ' +
              f"Les {len(qa['checks'])} contrôles techniques ont réussi sur le fichier " +
              f'`budget-clair-les-chemins.mp4` (SHA256 `{video_hash}`). ' +
              'La revue des captures réelles a été confirmée par l’opérateur au '
              'conditionnement. La piste AAC, ses niveaux et la conservation de '
              'la dernière phrase sont contrôlés par décodage et comparaison au '
              'mixage source. Les archives sont produites avec leurs empreintes.')
    readme = ROOT / 'README.md'
    content, count = re.subn(r'(?<=<!-- DELIVERY-STATUS:START -->).*?(?=<!-- DELIVERY-STATUS:END -->)',
                            '\n' + status + '\n', readme.read_text(), flags=re.S)
    if count != 1:
        raise ValueError('Bloc de statut unique introuvable dans README.md.')
    readme.write_text(content)
    metadata = {'project': 'Budget Clair — Les chemins', 'created_at_utc': now,
                'technical_qa_passed': True, 'visual_review_confirmed_by_operator': True,
                'audio_verification': 'Décodage AAC, niveaux, signal et corrélation de la fin avec le mix source.',
                'human_listening_attested': False,
                'video_sha256': video_hash, 'duration_seconds': 35,
                'video': 'H.264, yuv420p, 1080 × 1920, 30 i/s, faststart',
                'audio': 'AAC, stéréo 48 kHz',
                'voice': 'Synthèse locale Kokoro ff_siwis, pas la voix réelle de Romain.',
                'paid_service_used': False}
    OUT.mkdir(parents=True, exist_ok=True)
    sources = create_archive(OUT / 'budget-clair-les-chemins-sources.zip', source_files(),
                             {**metadata, 'archive_type': 'sources'})
    delivery_files = [(VIDEO.name, VIDEO), (COVER.name, COVER), ('voix-off.wav', VOICE),
                      ('texte-voix-off.txt', ROOT / 'texte-voix-off.txt'),
                      ('sous-titres.srt', ROOT / 'audio/narration/sous-titres.srt'),
                      ('README.md', readme), ('Refaire-le-rendu.txt', ROOT / 'Refaire-le-rendu.txt'),
                      ('qa/qa-final.json', QA),
                      ('provenance-voix.md', ROOT / 'audio/narration/PROVENANCE.md'),
                      ('provenance-musique.md', ROOT / 'audio/ambiance/PROVENANCE.md')]
    for name, path in [('budget-clair-les-chemins-mobile.mp4', OUT / 'budget-clair-les-chemins-mobile.mp4'),
                       ('qa/browser-qa.json', OUT / 'qa/browser-qa.json'),
                       ('qa/mobile-qa.json', OUT / 'qa/mobile-qa.json'),
                       ('qa/QA-VISUELLE.md', OUT / 'qa/QA-VISUELLE.md'),
                       ('voix-off.mp3', ROOT / 'audio/narration/voix-off.mp3'),
                       ('qa/QA-FINAL.md', OUT / 'qa/QA-FINAL.md')]:
        if path.is_file():
            delivery_files.append((name, path))
    delivery = create_archive(OUT / 'budget-clair-les-chemins-livraison.zip', delivery_files,
                              {**metadata, 'archive_type': 'livraison', 'sources_archive': sources})
    manifest = {**metadata, 'archives': [sources, delivery]}
    (OUT / 'livraison-manifest.json').write_bytes(json_bytes(manifest))
    targets = [VIDEO, OUT / 'budget-clair-les-chemins-mobile.mp4', COVER, OUT / sources['name'], OUT / delivery['name'],
               OUT / 'livraison-manifest.json']
    (OUT / 'SHA256SUMS.txt').write_text(''.join(
        f'{file_digest(path)}  {path.name}\n' for path in targets))
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as error:
        print(f'Conditionnement interrompu : {error}', file=sys.stderr)
        raise SystemExit(1)
