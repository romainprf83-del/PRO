#!/usr/bin/env python3
"""Vérification du véritable MP4 Budget Clair — Les chemins (35 secondes).

Python3, NumPy, Pillow, FFmpeg/FFprobe. Les mesures ne remplacent pas
la revue visuelle des captures du fichier exporté.
"""
from pathlib import Path
from fractions import Fraction
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
import math
import struct
import subprocess
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]


def run(args):
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError(args[0] + ' : ' + result.stderr.decode(errors='replace')[-2500:])
    return result


def db(value):
    return round(20*math.log10(max(float(value), 1e-12)), 3)


def audio_stats(samples):
    return {'sample_count_per_channel': len(samples),
            'rms_dbfs': db(np.sqrt(np.mean(samples.astype(np.float64)**2))),
            'peak_dbfs': db(np.max(np.abs(samples))),
            'clipped_samples': int(np.count_nonzero(np.abs(samples) >= .9999))}


def read_audio(path):
    raw = run(['ffmpeg','-v','error','-i',str(path),'-map','0:a:0',
               '-ar','48000','-ac','2','-f','f32le','-']).stdout
    return np.frombuffer(raw, dtype='<f4').reshape(-1,2)


def atoms(path):
    length=path.stat().st_size
    found=[]
    with path.open('rb') as source:
        while source.tell()<length:
            offset=source.tell()
            header=source.read(8)
            if len(header)!=8:
                raise ValueError('Bloc MP4 incomplet')
            size,kind=struct.unpack('>I4s',header)
            if size==1:
                size=struct.unpack('>Q',source.read(8))[0]
            elif size==0:
                size=length-offset
            if size<8 or offset+size>length:
                raise ValueError('Taille de bloc MP4 invalide')
            found.append({'type':kind.decode('ascii',errors='replace'),'offset':offset,'size':size})
            source.seek(offset+size)
    return found


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('video',nargs='?',default=str(ROOT/'output/budget-clair-les-chemins.mp4'))
    parser.add_argument('--output',default=str(ROOT/'output/qa'))
    parser.add_argument('--cta-box',default='80,180,840,1160',help='Zone stable x,y,w,h, hors sous-titres du bas')
    args=parser.parse_args()
    video=Path(args.video).resolve()
    output=Path(args.output).resolve()
    if not video.is_file():
        print(f'MP4 absent : {video}. Aucun contrôle final exécuté.',file=sys.stderr)
        return 2
    output.mkdir(parents=True,exist_ok=True)
    checks=[]

    def check(name,passed,observed):
        checks.append({'name':name,'passed':bool(passed),'observed':observed})

    check('MP4 non vide',video.stat().st_size>100000,video.stat().st_size)
    probe=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(video)]).stdout)
    (output/'ffprobe.json').write_text(json.dumps(probe,ensure_ascii=False,indent=2)+'\n')
    videos=[s for s in probe['streams'] if s['codec_type']=='video']
    audios=[s for s in probe['streams'] if s['codec_type']=='audio']
    check('une piste vidéo',len(videos)==1,len(videos))
    if not videos:
        raise RuntimeError('Aucune piste vidéo exploitable')
    v=videos[0]
    check('1080 × 1920',(v.get('width'),v.get('height'))==(1080,1920),[v.get('width'),v.get('height')])
    check('H.264',v.get('codec_name')=='h264',v.get('codec_name'))
    check('yuv420p',v.get('pix_fmt')=='yuv420p',v.get('pix_fmt'))
    fps=float(Fraction(v.get('avg_frame_rate','0/1')))
    check('30 images/seconde',abs(fps-30)<.001,fps)
    check('1050 images décodées',int(v.get('nb_read_frames',0))==1050,int(v.get('nb_read_frames',0)))
    check('vidéo de 35 secondes',abs(float(v.get('duration',0))-35)<=1/30,float(v.get('duration',0)))
    check('conteneur de 35 secondes',abs(float(probe['format']['duration'])-35)<.08,float(probe['format']['duration']))
    decoded=run(['ffmpeg','-v','error','-i',str(video),'-map','0:v:0','-map','0:a?','-f','null','-'])
    check('décodage complet sans erreur',not decoded.stderr.strip(),decoded.stderr.decode(errors='replace'))
    blocks=atoms(video)
    types=[a['type'] for a in blocks]
    check('vrai conteneur MP4','moov' in types and 'mdat' in types,blocks)
    faststart='moov' in types and 'mdat' in types and types.index('moov')<types.index('mdat')
    check('faststart',faststart,types)
    check('une piste audio présente',len(audios)==1,len(audios))
    audio_report=None
    if audios:
        check('audio AAC',audios[0].get('codec_name')=='aac',audios[0].get('codec_name'))
        sound=read_audio(video)
        check('audio couvre 35 secondes',len(sound)>=35*48000-1024,len(sound)/48000)
        sound=sound[:35*48000]
        whole=audio_stats(sound)
        last=audio_stats(sound[round(31.65*48000):round(33.23675*48000)])
        check('voix présente et audible',-36<whole['rms_dbfs']<-8,whole)
        check('audio sans écrêtage',whole['clipped_samples']==0,whole)
        check('dernière phrase présente et audible',-38<last['rms_dbfs']<-7,last)
        audio_report={'whole':whole,'last_phrase_31_65_to_33_23675':last,
                      'note':'La présence du signal final est mesurée dans le MP4. Le minutage intégral des mots est fourni par les segments de narration, sans prétendre faire une transcription automatique.'}
        source_mix=ROOT/'audio/budget-clair-les-chemins-mix.wav'
        if source_mix.is_file():
            reference=read_audio(source_mix)
            start=round(31.65*48000)
            end=round(33.23675*48000)
            reference_last=reference[start:end].mean(axis=1).astype(np.float64)
            comparison=[]
            for offset in range(-1024,1025,128):
                candidate=sound[start+offset:end+offset].mean(axis=1).astype(np.float64)
                if len(candidate)==len(reference_last):
                    comparison.append((float(np.corrcoef(reference_last,candidate)[0,1]),offset))
            correlation,offset=max(comparison)
            # Exact sample alignment is expected; nearby offsets tolerate codec delay.
            check('dernière phrase conservée dans le MP4',correlation>.9,
                  {'correlation_with_source_mix':correlation,'sample_offset':offset,
                   'interval_seconds':[31.65,33.23675]})
            audio_report['last_phrase_source_comparison']={'correlation':correlation,'sample_offset':offset}
        run(['ffmpeg','-v','error','-y','-ss','29.5','-i',str(video),'-t','5.5',
             '-map','0:a:0','-ar','48000','-ac','2','-c:a','pcm_s16le',str(output/'fin-audio-extraite-du-mp4.wav')])

    cue_path=ROOT/'audio/narration/captions.json'
    cues=json.loads(cue_path.read_text())
    last_cue=max(cues,key=lambda c:c['end'])
    check('aucune phrase source coupée à 35 secondes',all(0<=c['start']<c['end']<35 for c in cues),last_cue)
    check('dernière phrase complète selon la source',last_cue['text']=='écris BUDGET en commentaire.' and abs(last_cue['end']-33.23675)<.04,last_cue)
    check('deux lignes de sous-titres maximum',all(len(c.get('lines',[c['text']]))<=2 for c in cues),len(cues))
    check('sous-titres sans chevauchement temporel',
          all(cues[i].get('display_end',cues[i]['end'])<=cues[i+1]['start']+.001 for i in range(len(cues)-1)),
          [{'start':c['start'],'end':c['end'],'display_end':c.get('display_end',c['end'])} for c in cues])

    scenes=[0,.5,2,3.7,4,5.7,8.2,9.6,11.2,12.8,14,15.6,17.6,20.5,23.6,26.6,28.6,29,31.8,34.9]
    transitions=[8.7,8.85,9,9.15,9.3,14.7,14.85,15,15.15,15.3,28.7,28.85,29,29.15]
    captions=[round((c['start']+c['end'])/2,3) for c in cues]
    stable=[29,29.2,30,31,32,33,34,34.9]
    times=sorted(set(scenes+transitions+captions+stable))

    def frame_path(t):
        return output/f'frame-{round(t*1000):05d}ms.png'

    def extract(t):
        run(['ffmpeg','-v','error','-y','-threads','1','-ss',f'{t:.6f}','-i',str(video),'-frames:v','1','-threads','1',str(frame_path(t))])

    with ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(extract,times))
    fontpath=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
    font=ImageFont.truetype(str(fontpath),18) if fontpath.is_file() else ImageFont.load_default()

    def sheet(name,moments,columns=4):
        cw,ch=282,518
        canvas=Image.new('RGB',(columns*cw,math.ceil(len(moments)/columns)*ch),'#28314C')
        draw=ImageDraw.Draw(canvas)
        for i,t in enumerate(moments):
            x,y=i%columns*cw+6,i//columns*ch
            draw.text((x,y+5),f'{t:.2f} s',font=font,fill='#FFF6E6')
            with Image.open(frame_path(t)) as source:
                canvas.paste(source.convert('RGB').resize((270,480),Image.Resampling.LANCZOS),(x,y+31))
        canvas.save(output/name,quality=91)

    sheet('scenes.jpg',scenes)
    sheet('transitions-pate-a-modeler.jpg',transitions)
    sheet('sous-titres.jpg',captions)
    sheet('stabilite-cta.jpg',stable)
    nonblack=[]
    for t in scenes:
        pix=np.asarray(Image.open(frame_path(t)).convert('RGB'))
        lit=float(np.mean(np.any(pix>16,axis=2)))
        nonblack.append({'time':t,'mean_rgb':float(pix.mean()),'nonblack_fraction':lit})
    check('contenu visible dans chaque séquence',all(x['nonblack_fraction']>.05 for x in nonblack),nonblack)
    x,y,w,h=(int(v) for v in args.cta_box.split(','))
    base=np.asarray(Image.open(frame_path(29)).convert('RGB')).astype(np.float32)[y:y+h,x:x+w]
    comparisons=[]
    for t in stable[1:]:
        current=np.asarray(Image.open(frame_path(t)).convert('RGB')).astype(np.float32)[y:y+h,x:x+w]
        comparisons.append({'time':t,'mae_8bit':float(np.mean(np.abs(base-current))),
                            'fraction_diff_over_8':float(np.mean(np.max(np.abs(base-current),axis=2)>8))})
    check('CTA principal stable de 29 à 35 secondes',max(a['mae_8bit'] for a in comparisons)<2,
          {'region':[x,y,w,h],'reference':29,'comparisons':comparisons,
           'note':'La zone des sous-titres y=1440–1580 continue de suivre la voix : elle est exclue de la mesure. Le CTA lui-même doit rester fixe. Tolérance H.264 de 2 niveaux/255.'})
    failures=[c for c in checks if not c['passed']]
    report={'video':str(video),'size_bytes':video.stat().st_size,
            'sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'passed':not failures,
            'checks':checks,'failures':failures,'faststart':faststart,'audio':audio_report,
            'extracted_frames':len(times),'visual_review_required':True,
            'visual_review_note':'Examiner les quatre planches et les PNG pleine définition : proportions des illustrations, titres, pastilles, cadres, transitions en formes souples, sous-titres et CTA. Vérifier une écoute de la fin extraite. Les chiffres techniques ne remplacent pas cette revue.'}
    (output/'qa-final.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    lines=['# Contrôle du MP4 final','',f'Fichier : `{video.name}`','',f"SHA256 : `{report['sha256']}`",'',f'**{len(checks)-len(failures)}/{len(checks)} contrôles réussis.**','']
    lines += [f"- {'PASS' if c['passed'] else 'ÉCHEC'} — {c['name']}" for c in checks]
    lines += ['','## Revue visuelle','',report['visual_review_note'],'','Les captures sont extraites du MP4 réellement exporté. Elles ne sont pas des aperçus HTML.']
    (output/'QA-FINAL.md').write_text('\n'.join(lines)+'\n')
    print(f'{len(checks)-len(failures)}/{len(checks)} contrôles réussis ; {len(times)} images extraites.')
    if failures:print(json.dumps(failures,ensure_ascii=False,indent=2))
    return 1 if failures else 0


if __name__=='__main__':
    raise SystemExit(main())
