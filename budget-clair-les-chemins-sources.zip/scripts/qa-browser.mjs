/* Native Chromium MP4 playback QA. Does not render or modify the composition. */
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import puppeteer from 'puppeteer-core';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const videoPath=path.resolve(root,process.argv[2]||'output/budget-clair-les-chemins.mp4');
const output=path.join(root,'output/qa');
fs.mkdirSync(output,{recursive:true});
const report={video:videoPath,browser:'Chromium native HTMLVideoElement',checks:[],frames:[],errors:[]};
const check=(name,pass,details={})=>report.checks.push({name,pass:Boolean(pass),...details});
let browser;
let server;

try{
  const stat=fs.statSync(videoPath);
  check('file_exists_and_nonempty',stat.isFile()&&stat.size>10000,{bytes:stat.size});
  const document=`<!doctype html><html lang="fr"><meta charset="utf-8"><title>QA lecture MP4</title><style>html,body{margin:0;background:#222}video{display:block;width:540px;height:960px;object-fit:contain}</style><video id="video" controls muted playsinline preload="auto" src="/video.mp4"></video></html>`;
  server=http.createServer((req,res)=>{
    const pathname=new URL(req.url||'/', 'http://localhost').pathname;
    if(pathname==='/'){
      res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
      res.end(document);return;
    }
    if(pathname!=='/video.mp4'){res.writeHead(404);res.end();return;}
    const common={'Content-Type':'video/mp4','Accept-Ranges':'bytes','Cache-Control':'no-store'};
    let start=0,end=stat.size-1,status=200;
    if(req.headers.range){
      const m=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range);
      if(!m||(!m[1]&&!m[2])){res.writeHead(416,{...common,'Content-Range':`bytes */${stat.size}`});res.end();return;}
      if(!m[1]){start=Math.max(0,stat.size-Number(m[2]));}
      else{start=Number(m[1]);if(m[2])end=Math.min(Number(m[2]),stat.size-1);}
      if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>end||start>=stat.size){res.writeHead(416,{...common,'Content-Range':`bytes */${stat.size}`});res.end();return;}
      status=206;
      common['Content-Range']=`bytes ${start}-${end}/${stat.size}`;
    }
    res.writeHead(status,{...common,'Content-Length':end-start+1});
    if(req.method==='HEAD'){res.end();return;}
    const stream=fs.createReadStream(videoPath,{start,end});
    stream.on('error',()=>res.destroy());
    res.on('close',()=>stream.destroy());
    stream.pipe(res);
  });
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  const base=`http://127.0.0.1:${server.address().port}`;
  const range=await fetch(base+'/video.mp4',{headers:{Range:'bytes=0-15'}});
  const rangeBytes=await range.arrayBuffer();
  check('http_range_valid',range.status===206&&rangeBytes.byteLength===16&&range.headers.get('content-range')===`bytes 0-15/${stat.size}`,{status:range.status,contentRange:range.headers.get('content-range'),contentType:range.headers.get('content-type')});

  browser=await puppeteer.launch({executablePath:process.env.HYPERFRAMES_BROWSER_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  report.browserVersion=await browser.version();
  const page=await browser.newPage();
  page.on('pageerror',err=>report.errors.push(String(err)));
  await page.setViewport({width:540,height:960,deviceScaleFactor:1});
  await page.goto(base+'/',{waitUntil:'domcontentloaded',timeout:30000});
  await page.waitForFunction(()=>{const v=document.getElementById('video');return v.error||v.readyState>=2;},{timeout:30000});
  const meta=await page.evaluate(()=>{const v=document.getElementById('video');return {canPlayH264AAC:v.canPlayType('video/mp4; codecs="avc1.42E01F, mp4a.40.2"'),canPlayMP4:v.canPlayType('video/mp4'),videoWidth:v.videoWidth,videoHeight:v.videoHeight,duration:v.duration,readyState:v.readyState,error:v.error?{code:v.error.code,message:v.error.message}:null};});
  report.metadata=meta;
  check('browser_supports_h264_aac',Boolean(meta.canPlayH264AAC),{canPlayType:meta.canPlayH264AAC});
  check('native_video_metadata',meta.videoWidth===1080&&meta.videoHeight===1920&&Math.abs(meta.duration-35)<.05&&!meta.error,meta);
  if(meta.error)throw new Error(`Native video error ${meta.error.code}: ${meta.error.message}`);

  const playbackStart=await page.evaluate(async()=>{const v=document.getElementById('video');v.muted=true;await v.play();return v.currentTime;});
  await page.waitForFunction(start=>document.getElementById('video').currentTime>=start+.4,{timeout:15000},playbackStart);
  const playback=await page.evaluate(()=>{const v=document.getElementById('video');const r={currentTime:v.currentTime,paused:v.paused,readyState:v.readyState,quality:v.getVideoPlaybackQuality?{totalVideoFrames:v.getVideoPlaybackQuality().totalVideoFrames,droppedVideoFrames:v.getVideoPlaybackQuality().droppedVideoFrames}:null};v.pause();return r;});
  check('playback_advances_at_least_0_4s',playback.currentTime-playbackStart>=.4&&!playback.paused,{start:playbackStart,...playback});

  for(const time of [0.5,10.5,24,32,34.9]){
    const frame=await page.evaluate(async target=>{
      const v=document.getElementById('video');
      await new Promise((resolve,reject)=>{
        const timeout=setTimeout(()=>{cleanup();reject(new Error(`Seek timeout at ${target}s`));},10000);
        const cleanup=()=>{clearTimeout(timeout);v.removeEventListener('seeked',done);v.removeEventListener('error',fail);};
        const done=()=>{cleanup();resolve();};
        const fail=()=>{cleanup();reject(new Error('Video error during seek'));};
        v.addEventListener('seeked',done,{once:true});v.addEventListener('error',fail,{once:true});
        v.currentTime=target;
      });
      await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
      const canvas=document.createElement('canvas');canvas.width=v.videoWidth;canvas.height=v.videoHeight;
      const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(v,0,0);
      const d=ctx.getImageData(0,0,canvas.width,canvas.height).data;
      let sum=0,sum2=0,black=0,n=0,min=255,max=0;
      for(let i=0;i<d.length;i+=4*16){const y=.2126*d[i]+.7152*d[i+1]+.0722*d[i+2];sum+=y;sum2+=y*y;min=Math.min(min,y);max=Math.max(max,y);if(d[i]<16&&d[i+1]<16&&d[i+2]<16)black++;n++;}
      const mean=sum/n;
      return {time:target,actualTime:v.currentTime,readyState:v.readyState,width:canvas.width,height:canvas.height,meanLuma:mean,stdLuma:Math.sqrt(Math.max(0,sum2/n-mean*mean)),blackFraction:black/n,minLuma:min,maxLuma:max,png:canvas.toDataURL('image/png')};
    },time);
    const filename=`browser-frame-${String(time).replace('.','_')}s.png`;
    fs.writeFileSync(path.join(output,filename),Buffer.from(frame.png.split(',')[1],'base64'));
    delete frame.png;
    frame.path=path.relative(root,path.join(output,filename));
    report.frames.push(frame);
    check(`decoded_content_${time}s`,frame.width===1080&&frame.height===1920&&frame.readyState>=2&&Math.abs(frame.actualTime-time)<.05&&frame.meanLuma>20&&frame.stdLuma>4&&frame.blackFraction<.98,frame);
  }
  check('no_page_errors',report.errors.length===0,{errors:report.errors});
}catch(error){report.errors.push(String(error?.stack||error));check('execution_completed',false,{error:String(error)});}
finally{
  if(browser)await browser.close();
  if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
}
report.passed=report.checks.length>0&&report.checks.every(c=>c.pass)&&report.errors.length===0;
report.summary={passed:report.checks.filter(c=>c.pass).length,total:report.checks.length};
const reportPath=path.join(output,'browser-qa.json');
fs.writeFileSync(reportPath,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({passed:report.passed,summary:report.summary,report:reportPath,errors:report.errors},null,2));
if(!report.passed)process.exitCode=1;
