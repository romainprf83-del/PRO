/* Les PNG fournis restent aplatis. Les traits, cartes et formes sont des calques graphiques indépendants. */
(()=>{
const C={ivory:'#FAEBDD',cobalt:'#2848A8',apricot:'#ED9D65',lavender:'#A88AC6',ink:'#28314C',light:'#FFF7EE'};
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;');
const text=(id,x,y,lines,size=64,weight=800,anchor='start',fill=C.cobalt)=>`<text id="${id}" x="${x}" y="${y}" fill="${fill}" font-size="${size}" font-weight="${weight}" text-anchor="${anchor}">${lines.map((s,i)=>`<tspan x="${x}" dy="${i?size*1.17:0}">${esc(s)}</tspan>`).join('')}</text>`;
const tile=(x,y,w,h,fill=C.light,r=35)=>`<g filter="url(#clayShadow)"><rect x="${x}" y="${y+5}" width="${w}" height="${h}" rx="${r}" fill="${fill}"/><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="${fill}" stroke="${C.ink}" stroke-opacity=".1" stroke-width="2"/><path d="M${x+r} ${y+9}H${x+w-r}" fill="none" stroke="${C.light}" stroke-opacity=".45" stroke-width="4" stroke-linecap="round"/></g>`;
const pill=(id,x,y,w,label,fill)=>`<g id="${id}">${tile(x,y,w,94,fill,41)}<circle cx="${x+34}" cy="${y+47}" r="8" fill="${C.cobalt}"/>${text(id+'Text',x+57,y+62,[label],39,800,'start',C.ink)}</g>`;
const card=(id,x,y,w,lines,fill=C.light,size=39,n='')=>{const h=lines.length>1?132:102;return `<g id="${id}">${tile(x,y,w,h,fill,29)}${n?`<circle cx="${x+44}" cy="${y+h/2}" r="24" fill="${C.cobalt}"/>${text(id+'N',x+44,y+h/2+12,[n],31,800,'middle',C.light)}`:''}${text(id+'Text',x+(n?84:28),y+(lines.length>1?50:65),lines,size,700,'start',C.ink)}</g>`;};
const photo=(id,file,x=0,y=0,w=1080,h=1920)=>`<image id="${id}" href="assets/images/${file}" x="${x}" y="${y}" width="${w}" height="${h}" preserveAspectRatio="xMidYMid meet" data-layout-ignore/>`;
const frame=(id,x,y,w,h,color)=>`<path id="${id}" d="M${x} ${y+65}V${y+27}Q${x} ${y} ${x+27} ${y}H${x+65}M${x+w-65} ${y}H${x+w-27}Q${x+w} ${y} ${x+w} ${y+27}V${y+65}M${x+w} ${y+h-65}V${y+h-27}Q${x+w} ${y+h} ${x+w-27} ${y+h}H${x+w-65}M${x+65} ${y+h}H${x+27}Q${x} ${y+h} ${x} ${y+h-27}V${y+h-65}" fill="none" stroke="${color}" stroke-width="7" stroke-linecap="round" data-layout-ignore/>`;
const base=()=>`<defs><filter id="clayShadow" x="-15%" y="-30%" width="140%" height="175%"><feDropShadow dx="0" dy="8" stdDeviation="7" flood-color="#5F3D26" flood-opacity=".19"/></filter><linearGradient id="cityTop" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${C.ivory}"/><stop offset="1" stop-color="${C.ivory}" stop-opacity="0"/></linearGradient><clipPath id="headerClip"><rect x="0" y="100" width="1080" height="440"/></clipPath></defs><rect width="1080" height="1920" fill="${C.ivory}"/>`;
const finalScene=()=>`<g id="finalScene" opacity="0" data-layout-allow-overflow><rect width="1080" height="1920" fill="${C.ivory}"/><g data-layout-ignore>
<path d="M-98 80C148 65 120 266 55 378S126 571 26 658S-150 599-146 420Z" fill="${C.cobalt}"/><path d="M1093 218C879 214 978 421 951 536S1064 686 1152 576Z" fill="${C.apricot}"/><path d="M-67 1050C137 986 114 1206 47 1322S143 1538 3 1610L-149 1520Z" fill="${C.lavender}"/><path d="M1090 1181C902 1096 1002 1339 950 1432S1046 1623 1154 1481Z" fill="${C.cobalt}"/>
<path d="M-30 1781C181 1659 256 1938 443 1891S739 1757 845 1896L1080 1960H0Z" fill="${C.apricot}"/>
<path d="M-10 130Q66 189 23 278 M1008 293Q1010 359 1016 398 M-18 1120Q60 1164 29 1259" fill="none" stroke="${C.light}" stroke-width="6" opacity=".24" stroke-linecap="round"/></g>
${text('finalBrand',500,388,['Budget Clair'],62,800,'middle')}
<g id="commentIcon" data-layout-ignore><path d="M458 505H542Q571 505 571 534V579Q571 607 542 607H497L457 636V607Q429 607 429 579V534Q429 505 458 505Z" fill="${C.lavender}" filter="url(#clayShadow)"/><circle cx="468" cy="555" r="7" fill="${C.cobalt}"/><circle cx="500" cy="555" r="7" fill="${C.cobalt}"/><circle cx="532" cy="555" r="7" fill="${C.cobalt}"/></g>
${text('write',500,772,['ÉCRIS'],76,800,'middle')}
<g id="budgetHero">${tile(117,821,766,174,C.apricot,53)}${text('budgetHeroText',500,950,['BUDGET'],122,800,'middle')}</g>
${text('commentCta',500,1091,['EN COMMENTAIRE'],62,800,'middle')}
${text('finalSub',500,1240,['Pour découvrir','l’accompagnement'],39,600,'middle',C.ink)}
</g>`;
window.buildChemins=()=>{
document.getElementById('art').innerHTML=base()+`
<g id="cityScene" data-layout-allow-overflow>${photo('cityPhoto','01-ville-des-depenses.png',0,360,1080,1440)}<rect x="0" y="340" width="1080" height="260" fill="url(#cityTop)" data-layout-ignore/>
<g id="hookHeader" clip-path="url(#headerClip)">${text('hook',100,252,['TON ARGENT PART','DANS TOUS','LES SENS ?'],76)}</g>
<g id="questionHeader" opacity="0" clip-path="url(#headerClip)">${text('question',100,283,['ET TES','PROJETS ?'],104)}<path id="questionUnderline" d="M111 433Q406 451 725 432" fill="none" stroke="${C.apricot}" stroke-width="13" stroke-linecap="round"/></g>
${pill('housing',116,653,303,'Logement',C.apricot)}${pill('groceries',106,995,285,'Courses',C.lavender)}${pill('outings',622,875,261,'Sorties',C.light)}
<g id="cityRoute" data-layout-ignore><path id="routeShadow" d="M438 1393C117 1346 181 1051 549 1054S1017 943 760 768C598 656 312 698 290 540" fill="none" stroke="${C.light}" stroke-width="27" stroke-linecap="round"/><path id="route" d="M438 1393C117 1346 181 1051 549 1054S1017 943 760 768C598 656 312 698 290 540" fill="none" stroke="${C.apricot}" stroke-width="16" stroke-linecap="round"/><circle id="routeEnd" cx="290" cy="540" r="15" fill="${C.apricot}"/></g>
</g>
<g id="projectsScene" opacity="0" data-layout-allow-overflow>${photo('projectsPhoto','02-chemin-des-projets.png')}
${text('projectsTitle',100,246,['FAIS UNE PLACE','À CE QUI COMPTE.'],67)}
${frame('homeFrame',75,718,326,428,C.cobalt)}${frame('caseFrame',753,1060,220,270,C.apricot)}${frame('umbrellaFrame',555,625,420,280,C.lavender)}
${card('appart',100,549,405,['Ton premier','appart'],C.light,39)}
${card('voyage',610,941,290,['Un voyage'],C.apricot,38)}
${card('reserve',559,481,341,['Une réserve'],C.lavender,38)}
</g>
<g id="meetingScene" opacity="0" data-layout-allow-overflow>${photo('meetingPhoto','03-accompagnement.png')}
<g id="supportHeader">${text('supportTitle',100,235,['ON REGARDE TON','BUDGET ENSEMBLE.'],64)}</g>
<g id="rhythmHeader" opacity="0">${text('rhythm',100,242,['À TON RYTHME.','SANS JUGEMENT.'],69)}</g>
${text('brand',100,402,['Budget Clair'],34,800,'start',C.cobalt)}
${card('exchange',100,449,800,['Un échange personnel'],C.light,41,'1')}
${card('excel',100,582,800,['Ton tableau Excel adapté'],C.light,39,'2')}
${card('follow',100,1230,800,['Un point de suivi','pour ajuster'],C.light,42,'3')}
</g>
${finalScene()}
<g id="orangeClay" opacity="0" data-layout-ignore><path d="M278 499C319 493 336 526 326 561S270 589 253 563S243 510 278 499Z" fill="${C.apricot}"/></g>
<g id="lavenderClay" opacity="0" data-layout-ignore><path d="M-140 -120C160-218 397-132 660-151S1130-188 1220 65L1284 1643Q1301 2103 913 2070L230 2092Q-211 2059-163 1638Z" fill="${C.lavender}"/></g>
<g id="ivoryClay" opacity="0" data-layout-ignore><path d="M-140 -120C160-218 397-132 660-151S1130-188 1220 65L1284 1643Q1301 2103 913 2070L230 2092Q-211 2059-163 1638Z" fill="${C.ivory}"/></g>
<g id="captions"></g>`;
const tl=gsap.timeline({paused:true});
const pop=(id,t,d=.48)=>tl.from('#'+id,{opacity:0,y:28,scale:.95,transformOrigin:'50% 50%',duration:d,ease:'back.out(1.25)'},t);
const head=(id,t,d=.48)=>tl.from('#'+id,{opacity:0,y:24,duration:d,ease:'power3.out'},t);
head('hook',.1,.42);
tl.from('#cityPhoto',{scale:1.014,svgOrigin:'540 1020',duration:4,ease:'sine.out'},.1);
pop('housing',1);pop('groceries',1.7);pop('outings',2.4);
// La question se révèle dans le même décor, avec une transition locale du titre.
tl.to('#hookHeader',{opacity:0,duration:.2,ease:'sine.inOut'},4.0);tl.to('#questionHeader',{opacity:1,duration:.28,ease:'sine.inOut'},4.14);head('question',4.02,.5);
tl.from('#questionUnderline',{scaleX:0,transformOrigin:'0% 50%',duration:.6,ease:'power2.inOut'},4.4);
tl.to('#cityPhoto',{scale:1.025,x:-7,y:-7,svgOrigin:'540 1100',duration:4.8,ease:'sine.inOut'},4);
for(const id of ['route','routeShadow']){const node=document.getElementById(id),len=node.getTotalLength();tl.fromTo(node,{strokeDasharray:len,strokeDashoffset:len},{strokeDashoffset:0,duration:1.4,ease:'power2.inOut'},4.8);}
pop('routeEnd',6.13,.32);
// Le bout du chemin devient une nappe de pâte orange. Seul ce graphisme se déforme.
tl.set('#orangeClay',{opacity:1,scale:0.05,svgOrigin:'290 540'},8.68);
tl.to('#orangeClay',{scaleX:62,scaleY:67,duration:.32,ease:'power2.in'},8.68);
tl.set('#projectsScene',{opacity:1},9);tl.set('#cityScene',{opacity:0},9);
tl.to('#orangeClay',{scaleX:0.03,scaleY:0.05,x:950,y:-400,duration:.32,ease:'power3.out'},9);
tl.set('#orangeClay',{opacity:0},9.32);
head('projectsTitle',9.12,.42);
tl.from('#projectsPhoto',{scale:1.012,svgOrigin:'540 1020',x:4,duration:5.7,ease:'sine.inOut'},9.1);
pop('voyage',9.28,.45);pop('appart',9.8,.48);pop('reserve',11.72,.5);
for(const [id,t]of [['caseFrame',9.28],['homeFrame',9.8],['umbrellaFrame',11.72]])tl.from('#'+id,{opacity:0,scale:.96,transformOrigin:'50% 50%',duration:.65,ease:'sine.out'},t);
// Deuxième couverture de pâte, au même rythme que la première.
tl.set('#lavenderClay',{opacity:1,x:-1500},14.7);tl.to('#lavenderClay',{x:0,scaleX:1.04,svgOrigin:'540 960',duration:.3,ease:'power2.inOut'},14.7);
tl.set('#meetingScene',{opacity:1},15);tl.set('#projectsScene',{opacity:0},15);
tl.to('#lavenderClay',{x:1500,scaleX:.95,duration:.32,ease:'power2.inOut'},15);tl.set('#lavenderClay',{opacity:0},15.32);
head('supportTitle',15.08,.5);tl.from('#brand',{opacity:0,x:-18,duration:.55,ease:'sine.out'},15.4);
tl.from('#meetingPhoto',{x:5,scale:1.006,svgOrigin:'540 1060',duration:7.3,ease:'sine.inOut'},15.1);
pop('exchange',16.5,.5);pop('excel',20.1,.48);pop('follow',23.4,.5);
tl.to('#meetingPhoto',{scale:1.022,y:-9,svgOrigin:'540 1040',duration:4.6,ease:'sine.inOut'},23);
tl.to('#supportHeader',{opacity:0,duration:.24,ease:'sine.inOut'},26.0);tl.to('#rhythmHeader',{opacity:1,duration:.32,ease:'sine.inOut'},26.2);head('rhythm',26.04,.45);
// L’écran final et toutes ses entrées sont terminés à 29.000 s.
tl.set('#ivoryClay',{opacity:1,x:-1500},28.42);tl.to('#ivoryClay',{x:0,duration:.24,ease:'power2.inOut'},28.42);
tl.set('#finalScene',{opacity:1},28.66);tl.set('#meetingScene',{opacity:0},28.66);
tl.to('#ivoryClay',{x:1500,duration:.34,ease:'power2.inOut'},28.66);tl.set('#ivoryClay',{opacity:0},29);
head('finalBrand',28.66,.29);pop('commentIcon',28.66,.31);head('write',28.67,.29);pop('budgetHero',28.68,.31);head('commentCta',28.68,.3);head('finalSub',28.69,.3);
const captions=document.getElementById('captions');
for(const c of window.CHEMINS_CAPTIONS||[]){
 const id='caption-'+c.id,lines=c.lines,y=lines.length===1?1519:1487;
 captions.insertAdjacentHTML('beforeend',`<g id="${id}" opacity="0"><rect x="93" y="1435" width="814" height="143" rx="29" fill="${C.ink}" fill-opacity=".94"/>${text(id+'Text',500,y,lines,44,600,'middle',C.light)}</g>`);
 tl.set('#'+id,{opacity:1},c.start);tl.set('#'+id,{opacity:0},c.display_end??c.end);
}
return tl;
};
window.buildCheminsCover=()=>{
document.getElementById('art').innerHTML=base()+photo('coverPhoto','02-chemin-des-projets.png')+`
${text('coverTitle',100,242,['ET TES PROJETS','DANS TOUT ÇA ?'],78)}
<path d="M110 377Q412 397 832 378" stroke="${C.apricot}" stroke-width="13" stroke-linecap="round" fill="none"/>
${card('coverBrand',100,432,477,['Budget Clair'],C.light,51)}
<g data-layout-ignore><path d="M-20 1830Q173 1726 373 1826T826 1824T1110 1816V1940H-20Z" fill="${C.cobalt}"/></g>`;
};
})();
