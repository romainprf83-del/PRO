# Contrôle du MP4 final

Fichier : `budget-clair-les-chemins.mp4`

SHA256 : `a6ac5133d20f2f15791c4bb77c18f4c4dc7ef4704aae537c73b3effce46c58bd`

**25/25 contrôles réussis.**

- PASS — MP4 non vide
- PASS — une piste vidéo
- PASS — 1080 × 1920
- PASS — H.264
- PASS — yuv420p
- PASS — 30 images/seconde
- PASS — 1050 images décodées
- PASS — vidéo de 35 secondes
- PASS — conteneur de 35 secondes
- PASS — décodage complet sans erreur
- PASS — vrai conteneur MP4
- PASS — faststart
- PASS — une piste audio présente
- PASS — audio AAC
- PASS — audio couvre 35 secondes
- PASS — voix présente et audible
- PASS — audio sans écrêtage
- PASS — dernière phrase présente et audible
- PASS — dernière phrase conservée dans le MP4
- PASS — aucune phrase source coupée à 35 secondes
- PASS — dernière phrase complète selon la source
- PASS — deux lignes de sous-titres maximum
- PASS — sous-titres sans chevauchement temporel
- PASS — contenu visible dans chaque séquence
- PASS — CTA principal stable de 29 à 35 secondes

## Revue visuelle

Examiner les quatre planches et les PNG pleine définition : proportions des illustrations, titres, pastilles, cadres, transitions en formes souples, sous-titres et CTA. Vérifier une écoute de la fin extraite. Les chiffres techniques ne remplacent pas cette revue.

Les captures sont extraites du MP4 réellement exporté. Elles ne sont pas des aperçus HTML.
