# Revue des images du véritable MP4

Fichier examiné : `budget-clair-les-chemins.mp4` — SHA256 `a6ac5133d20f2f15791c4bb77c18f4c4dc7ef4704aae537c73b3effce46c58bd`.

Les quatre planches `scenes.jpg`, `transitions-pate-a-modeler.jpg`, `sous-titres.jpg` et `stabilite-cta.jpg` ont été examinées, ainsi que les captures pleine définition à 5,7 s et 23,6 s. Elles proviennent du MP4 final, pas du navigateur de création.

- Les trois illustrations correspondent bien aux scènes ville, projets et rencontre. Les personnages et objets conservent leurs proportions.
- Le contenu est visible, sans scène noire. Les aplats orange, lavande et ivoire aux changements de scène sont les transitions graphiques prévues.
- Les titres et cartes restent lisibles. Les visages de la rencontre sont dégagés. Les sous-titres occupent une zone séparée des titres et comportent au maximum deux lignes.
- La dernière question de la première scène tient désormais sur deux lignes complètes dans un seul groupe, sans changement de sous-titre en milieu de question.
- Le CTA exact « ÉCRIS BUDGET EN COMMENTAIRE » est visible et stable de 29 à 35 s. Le sous-texte et la signature sont présents. Seuls les sous-titres continuent de suivre la voix dans leur zone réservée.
- Aucun défaut visuel bloquant constaté dans les captures examinées.

## Contrôle audio mesuré

Le signal du MP4 est présent, à −20,153 dBFS RMS et −5,289 dBFS de crête, sans écrêtage. La dernière phrase entre 31,65 et 33,23675 s est complète par comparaison avec le mix source (corrélation 0,999871, décalage 0 échantillon). La fin audio a également été extraite dans `fin-audio-extraite-du-mp4.wav` pour une écoute éventuelle. Ces mesures ne constituent pas une transcription ni une écoute humaine du rendu.

Les 25 contrôles automatiques ont réussi. Rapport détaillé : `qa-final.json` et `QA-FINAL.md`.
